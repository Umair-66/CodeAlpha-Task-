# app_secure.py - Hardened example for reference
from flask import Flask, request, jsonify, abort
import sqlite3, subprocess, shlex, os
from werkzeug.utils import secure_filename
from pathlib import Path

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "change-me-in-env")
app.debug = False

DB_PATH = "users.db"

def init_db():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username TEXT, password_hash TEXT)")
    conn.commit()
    conn.close()

@app.route("/login", methods=["POST"])
def login():
    username = request.form.get("username", "")
    password = request.form.get("password", "")
    if not username or not password:
        abort(400, "Missing fields")
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT id, username FROM users WHERE username=? AND password_hash=?",
                (username, password))
    row = cur.fetchone()
    conn.close()
    if row:
        return jsonify({"status": "ok", "user": row[1]})
    return jsonify({"status": "fail"}), 401

@app.route("/exec")
def exec_cmd():
    cmd = request.args.get("cmd")
    if not cmd:
        abort(400, "Missing cmd")
    try:
        out = subprocess.check_output(shlex.split(cmd), stderr=subprocess.STDOUT, timeout=3)
    except Exception as e:
        return jsonify({"error": str(e)}), 400
    return jsonify({"out": out.decode("utf-8", errors="ignore")})

@app.route("/read")
def read_file():
    name = request.args.get("name")
    if not name:
        abort(400, "Missing name")
    filename = secure_filename(name)
    base_dir = Path(".").resolve()
    target = (base_dir / filename).resolve()
    if base_dir not in target.parents and base_dir != target:
        abort(403, "Path traversal rejected")
    try:
        with open(target, "r", encoding="utf-8") as f:
            return f.read()
    except Exception as e:
        return jsonify({"error": str(e)}), 404

@app.route("/health")
def health():
    return "OK"

if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=5000)
