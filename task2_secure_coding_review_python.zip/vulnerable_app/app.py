# app.py (VULNERABLE ON PURPOSE) - For educational code review only
from flask import Flask, request, jsonify
import sqlite3, os, subprocess, pickle

app = Flask(__name__)
app.config["SECRET_KEY"] = "hardcoded-dev-secret"  # hardcoded secret
app.debug = True  # debug mode in production (vuln)

DB_PATH = "users.db"

def init_db():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username TEXT, password TEXT)")
    cur.execute("INSERT OR IGNORE INTO users (id, username, password) VALUES (1, 'admin', 'admin123')")
    conn.commit()
    conn.close()

@app.route("/login", methods=["POST"])
def login():
    username = request.form.get("username", "")
    password = request.form.get("password", "")
    # SQL INJECTION: string formatting without parameters
    query = f"SELECT * FROM users WHERE username = '{username}' AND password = '{password}'"
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(query)  # vulnerable
    user = cur.fetchone()
    conn.close()
    if user:
        return jsonify({"status": "ok", "user": username})
    return jsonify({"status": "fail"}), 401

@app.route("/exec")
def exec_cmd():
    # COMMAND INJECTION: user input executed in shell
    cmd = request.args.get("cmd", "echo hello")
    out = subprocess.check_output(cmd, shell=True)  # vulnerable
    return jsonify({"out": out.decode("utf-8", errors="ignore")})

@app.route("/read")
def read_file():
    # PATH TRAVERSAL: no sanitization (e.g., ../../etc/passwd)
    name = request.args.get("name", "app.py")
    with open(name, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()

@app.route("/calc")
def calc():
    # CODE INJECTION: evaluating user input
    expr = request.args.get("expr", "1+1")
    return str(eval(expr))  # vulnerable

@app.route("/loads", methods=["POST"])
def loads():
    # UNSAFE DESERIALIZATION
    data = request.get_data()
    obj = pickle.loads(data)  # vulnerable
    return jsonify({"type": str(type(obj))})

@app.route("/health")
def health():
    return "OK"

if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=5000)
